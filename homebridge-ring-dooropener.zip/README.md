# Homebridge Ring Intercom Dooropener

Ein minimales Homebridge-Plugin, das ausschließlich den Türöffner eines Ring Intercom in HomeKit integriert – ohne Audio, Motion, Klingel oder Benachrichtigungen.

## Installation

```bash
npm install -g homebridge-ring-dooropener
```

## Konfiguration

```json
{
  "platform": "RingIntercomOpener",
  "refreshToken": "DEIN_REFRESH_TOKEN",
  "intercomName": "Haustür"
}
```

## Verhalten
- Zeigt in HomeKit ein Schloss an
- Öffnet Tür über Ring API beim Aktivieren
- Setzt Status automatisch nach 5 Sekunden zurück
